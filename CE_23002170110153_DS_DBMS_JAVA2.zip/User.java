class User {
    int id;
    String username;
    String password;
    String email;
    String profile;

    User(int id, String username, String password, String email, String profile) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.email = email;
        this.profile = profile;
    }
}