class Booking {
    int id;
    String user_name;
    String game_name;
    String bookingDate;
    String bookingTime;

    Booking(int id, String user_name ,String game_name, String bookingDate, String bookingTime) {
        this.id = id;
        this.user_name = user_name;
        this.game_name = game_name;
        this.bookingDate = bookingDate;
        this.bookingTime = bookingTime;
    }
}